//
//  ATZAppDelegate.h
//  TestProject
//
//  Created by Marin Usalj on 3/2/14.
//  Copyright (c) 2014 Marin Usalj. All rights reserved.
//

#import <Cocoa/Cocoa.h>

@interface ATZAppDelegate : NSObject <NSApplicationDelegate>

@property (assign) IBOutlet NSWindow *window;

@end
