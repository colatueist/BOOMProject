//
//  ATZInstallerTests.m
//  Alcatraz
//
//  Created by Marin Usalj on 11/23/13.
//  Copyright 2013 supermar.in. All rights reserved.
//

#import <Kiwi/Kiwi.h>
#import "ATZInstaller.h"


SPEC_BEGIN(ATZInstallerTests)

describe(@"ATZInstaller", ^{

//    ATZInstaller *installer = [ATZInstaller new];
//    
//    it(@"stops installing if download returned an error", ^{
//        
//    });
    
});

SPEC_END
